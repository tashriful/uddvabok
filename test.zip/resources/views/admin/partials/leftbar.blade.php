 <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.index') }}"><span class="menu-title">Dashboard</span></a></li>
          <li class="nav-item"><a class="nav-link" href=" {{ route('admin.profile') }}"><span class="menu-title">Profile</span></a></li>
          <!--<li class="nav-item"><a class="nav-link" href="{{ route('admin.userAdd') }}"><span class="menu-title">Admin Add</span></a></li>-->
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.resellerShow') }}"><span class="menu-title">Reseller List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.userAdd') }}"><span class="menu-title">Admin List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.supplierShow') }}"><span class="menu-title">Supplier List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.productAdd') }}"><span class="menu-title">Add Product</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.productShow') }}"><span class="menu-title">Product List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.order') }}"><span class="menu-title">Order List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.account') }}"><span class="menu-title">Account</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.categoryCreate') }}"><span class="menu-title">Add Category</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.categoryShow') }}"><span class="menu-title">Category List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="pages/ui-features/buttons.html"><span class="menu-title">Buttons</span></a></li>
          
          
         
        </ul>
      </nav>