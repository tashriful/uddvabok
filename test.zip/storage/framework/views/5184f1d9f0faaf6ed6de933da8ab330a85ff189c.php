<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
                <h3>Supplier Accounts</h3>
                 <table class="table table-dark">
                          <thead>
                              <tr>
                                  <th scope="col">Order No</th>
                                  <th scope="col">Product Name</th>
                                  <th scope="col">Payable Ammount</th>
                                  <th scope="col">Status</th>
                                  
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <th scope="row"><?php echo e($order['id']); ?></th>
                                  <td><?php echo e($order->product->title); ?></td>
                                  <td>
                                 
                                  <?php echo e(\App\product::where(['id' => $order->product_id])->pluck('price')->first()); ?>

                                  
                                  </td>
                                  <td>
                                      <p>
                                          <?php if($order->is_paid): ?>
                                          <button type="button" class="btn btn-success btn-sm">Paid</button>
                                          <?php else: ?>
                                          <button type="button" class="btn btn-danger btn-sm">Unpaid</button>
                                          <?php endif; ?>
                                      </p>
                                  </td>
                              </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
</table>
                     
                     
                  </div>
              </div>


          </div>
      </div>
      <!-- main-panel ends -->


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/supplier/pages/account.blade.php ENDPATH**/ ?>