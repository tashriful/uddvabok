<?php $__env->startSection('content'); ?>

  <!-- Start Sidebar + Content -->
  <div style="background-color:#FFFFFF;" class='container margin-top-20'>
  
  <?php echo $__env->make('home.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
          <div style="background-color:" class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-4">
               
                <div class="card-body">
                    <div class="card"> <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img style="height:200px; width:300px; " class="card-img-top feature-img" src="<?php echo e(asset('images/products/'. $image->image)); ?>" height="" width="" alt="Card image">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <div class="card-body">
                  <a href="<?php echo e(route('home.productDetails' ,$product->id)); ?>"><h4 class="card-title"> <?php echo e($product->title); ?> </h4></a>
                  <p class="card-text"><?php echo e($product->price); ?></p>
                  <?php echo $__env->make('home.pages.orderButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
              </div>
            </div>
              </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

          </div>
        </div>
        <div class="widget">

        </div>
      </div>


    </div>
  </div>

  <!-- End Sidebar + Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/home/pages/categoryProduct.blade.php ENDPATH**/ ?>