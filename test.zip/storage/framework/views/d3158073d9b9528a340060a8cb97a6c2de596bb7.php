<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>LOGIN PAGE</h1>

	<form method="post">
	<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>Username</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit"></td>
				<td></td>
			</tr>
		</table>
	</form>
</body>
</html><?php /**PATH F:\laravel aiub\test\test\resources\views/login/index.blade.php ENDPATH**/ ?>