      <?php $__env->startSection('content'); ?>
      
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                      Show Product
                  </div>
                 
                       <?php echo $__env->make('supplier.layouts.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                      <table class="table table-dark">
                          <thead>
                              <tr>
                                  <th scope="col">Title</th>
                                  <th scope="col">Price</th>
                                  <th scope="col">Quantity</th>
                                  <th scope="col">Status</th>
                                  <th scope="col">Description</th>
                                  <th scope="col">Action</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <th scope="row"><?php echo e($product['title']); ?></th>
                                  <td><?php echo e($product['price']); ?></td>
                                  <td><?php echo e($product['quantity']); ?></td>
                                  <td> <?php if( $product['status'] == 0): ?>
                                  Deactive
                                  <?php endif; ?>
                                  <?php if( $product['status'] == 1): ?>
                                  Active
                                  <?php endif; ?>
                                  </td>
                                  <td><?php echo e($product['description']); ?></td>
                                  <td>
                                       <a href="<?php echo e(route('supplier.productEdit' , $product->id)); ?>" >Update</a> |
                                      <!-- Button trigger modal -->
                                      
                                      <!-- Modal -->
                                      <!--<div class="modal fade" id="deleteModal<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                  <div class="modal-header">
                                                      <h5 style="color:black;" class="modal-title" id="exampleModalLabel">Are you want to delete??</h5>
                                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                      </button>
                                                  </div>
                                                  <div class="modal-body">
                                                      <form action="<?php echo e(route('supplier.product.delete', $product->id)); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?>   
                                                          
                                                          <button type="submit" class="btn btn-danger" >Delete</button>-->
                                                          
                                                      </form>
                                                      <!--<div class="modal-footer">
                                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                      </div>-->
                                                  </div>
                                                
                                              </div>
                                          </div>
                                      </div>



                                  </td>
                                  </tr>

                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                     
                     
                  </div>
              </div>


          </div>
      </div>
      <!-- main-panel ends -->


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/supplier/pages/productShow.blade.php ENDPATH**/ ?>