<?php $__env->startSection('sub_content'); ?>

   <div class='container-fluid margin-top-20'>
                  
                          <h3>Welcome <?php echo e($user->name); ?></h3>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.userMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/home/pages/userDashboard.blade.php ENDPATH**/ ?>