      <?php $__env->startSection('content'); ?>
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                      Order Information
                  </div>
                  <div class="card-body">

                     <table border="0">
                    <tr>
                        <td>Product Name :</td>
                        <td><?php echo e($order->product->title); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Quantity :</td>
                        <td><?php echo e($order->quantity); ?></td>
                    </tr>
                    <tr>
                        <td>Price :</td>
                        <td><?php echo e($order->price); ?></td>
                    </tr>
                    <tr>
                        <td>Customer Name :</td>
                        <td><?php echo e($order->name); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Customer Number :</td>
                        <td><?php echo e($order->number); ?></td>
                    </tr>
                    <tr>
                        <td>Customer Address :</td>
                        <td>
                            <?php echo e($order->address); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <form action="<?php echo e(route('admin.paid' , $order->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php if($order->is_paid): ?>
                                <input type="submit" class="btn btn-success" name="complete" value="Payement Paid">
                                <?php else: ?>
                                <input type="submit" class="btn btn-danger" name="complete" value="Pending Payment">
                                <?php endif; ?>
                            </form>
                        </td>
                       
                    </tr>
                </table>
                  </div>
                  </div>


                  </div>
                  </div>
                  <!-- main-panel ends -->


                  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/orderShow.blade.php ENDPATH**/ ?>