<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="card">
            <div class="card-header">
                Reseller Information
            </div>
            <div class="card-body">
                <?php if(Session::has('success')): ?>
                <div class="alert alert-success">

                    <p><?php echo e(Session::get('success')); ?></p>
                </div>
                <?php endif; ?>

                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Company Name</th>
                            <th scope="col">Business Category</th>
                            <th scope="col">Email</th>
                            <th scope="col">Number</th>
                            <th scope="col">Address</th>
                            <th scope="col">Status</th>
                            <th scope="col">User Name</th>
                            <th scope="col">Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($value['name']); ?></th>
                            <td><?php echo e($value['company_name']); ?></td>
                            <td><?php echo e($value['business_category']); ?></td>
                            <td><?php echo e($value['email']); ?></td>
                            <td><?php echo e($value['number']); ?></td>
                            <td><?php echo e($value['address']); ?></td>
                            <td>
                                <?php if( $value['status'] == 0): ?>
                                Deactive
                                <?php endif; ?>
                                <?php if( $value['status'] == 1): ?>
                                Active
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($value['username']); ?></td>
                            <td>
                                <a href="#deleteModal<?php echo e($value->id); ?>" data-toggle="modal">Remove</a> |
                                <a href="<?php echo e(route('admin.resellerEdit' , $value->id)); ?>">Update</a> |
                                <!-- Button trigger modal -->

                                <!-- Modal -->
                                <div class="modal fade" id="deleteModal<?php echo e($value->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 style="color:black;" class="modal-title" id="exampleModalLabel">Are you want to delete??</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('admin.resellerDelete', $value->id)); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>


                                                    <button type="submit" class="btn btn-danger">Delete</button>

                                                </form>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>



                            </td>


                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>


    </div>
</div>
<!-- main-panel ends -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/resellerShow.blade.php ENDPATH**/ ?>