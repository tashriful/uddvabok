<!DOCTYPE html>
<html>
<head>
	<title>Student List</title>
</head>
<body>

	<h2>Student List:</h2>
	
	<a href="/home">Back</a> |
	<a href="/logout">logout</a>

	<table border="1">
		<tr>
			<td>ID</td>
			<td>Name</td>
			<td>CGPA</td>
			<td>Action</td>
		</tr>
		<?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($value[0]); ?></td>
			<td><?php echo e($value[1]); ?></td>
			<td><?php echo e($value[2]); ?></td>
			<td>
				<a href="/edit/<?php echo e($value[0]); ?>">Edit</a> |
				<a href="/delete/<?php echo e($value[0]); ?>">Delete</a> |
				<a href="/details/<?php echo e($value[0]); ?>">Details</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

</body>
</html><?php /**PATH F:\laravel aiub\test\test\resources\views/home/stdlist.blade.php ENDPATH**/ ?>