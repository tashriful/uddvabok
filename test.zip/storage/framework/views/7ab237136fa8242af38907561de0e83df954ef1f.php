 <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('supplier.dashboard')); ?>"><span class="menu-title">Dashboard</span></a></li>
          <li class="nav-item"><a class="nav-link" href=" <?php echo e(route('supplier.productAdd')); ?>"><span class="menu-title">Profile</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('supplier.productAdd')); ?>"><span class="menu-title">Add Product</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('supplier.productShow')); ?>"><span class="menu-title">Product List</span></a></li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('supplier.order')); ?>"><span class="menu-title">Orders</span></a></li>
         
        </ul>
      </nav><?php /**PATH F:\laravel aiub\test\test\resources\views/supplier/partials/leftbar.blade.php ENDPATH**/ ?>