<form class="form-inline" action="<?php echo e(route('home.userOrderButton')); ?>" method="post">
 <?php echo csrf_field(); ?>
    
   <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
    <input type="hidden" name="uploader_id" value="<?php echo e($product->user_id); ?>">    
             
  <button type="submit" value="submit" class="btn btn-dark">Order</button>  
    
</form>



<?php /**PATH F:\laravel aiub\test\test\resources\views/home/pages/orderButton.blade.php ENDPATH**/ ?>