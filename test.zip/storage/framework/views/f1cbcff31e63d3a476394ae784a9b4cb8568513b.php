      <?php $__env->startSection('content'); ?>
      
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                      Add Category
                  </div>
                  <div class="card-body">
                         

                     
                      <form action="" method="post" enctype="multipart/form-data" >
                        
                        <?php echo csrf_field(); ?>
                        
                         <?php echo $__env->make('admin.layouts.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        
                         <div class="form-group">
                              <label for="exampleInputName">Category Name</label>
                              <input type="text" class="form-control" name="name" placeholder="Category Name">
                          </div>
                          
                          
                          <button type="submit" name="submit" value="submit" class="btn btn-primary">Submit</button>
                      </form>

                  </div>
              </div>


          </div>
      </div>
      <!-- main-panel ends -->


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/categoryCreate.blade.php ENDPATH**/ ?>