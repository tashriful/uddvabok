    
<footer class="footer-bottom">
  <p class="text-center">&copy; 2019 All rights reserved |</p>
</footer><?php /**PATH F:\laravel aiub\test\test\resources\views/home/partials/footer.blade.php ENDPATH**/ ?>