@extends('home.layouts.userMaster')

@section('sub_content')

   <div class='container-fluid margin-top-20'>
                  
                          <h3>Welcome {{ $user->name}}</h3>
</div>
@endsection