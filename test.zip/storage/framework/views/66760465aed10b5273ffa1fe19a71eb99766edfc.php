<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="" href="index.html"><h1>Supplier Panel</h1></a>
      </div>
       
       <div class="navbar-menu-wrapper d-flex align-items-center">
        <!--<ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item">
            <a href="#" class="nav-link"><i class="mdi mdi-image-filter"></i>Gallery</a>
          </li>
          <li class="nav-item active">
            <a href="#" class="nav-link"><i class="mdi mdi-email-outline"></i>Inbox</a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link"><i class="mdi mdi-calendar"></i>Calendar</a>
          </li>
        </ul>-->
        <ul class="navbar-nav ml-auto">
             <?php if(auth()->guard()->guest()): ?>
             <li class="nav-item">
                 <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
             </li>
             <?php if(Route::has('register')): ?>
             <li class="nav-item">
                 <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
             </li>
             <?php endif; ?>
             <?php else: ?>
             <li class="nav-item dropdown">
                
                 <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                     <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                 </a>

                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    
                    
                    
                    
                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                         <?php echo e(__('Logout')); ?>

                     </a>
                     

                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form>
                 </div>
             </li>
             <?php endif; ?>
         </ul>
        </div>
        
      
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
    </nav><?php /**PATH F:\laravel aiub\test\test\resources\views/supplier/partials/navbar.blade.php ENDPATH**/ ?>