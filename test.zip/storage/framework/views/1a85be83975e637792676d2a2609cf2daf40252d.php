 <div class="container-fluid" style="background-color:white !important">
 <br>
 <br><br><br><br>
</div>
 <div class="container-fluid" style="background-color:white !important#bb2525">

    <nav class="navbar fixed-top navbar-expand-md bg-light navbar-light"  style="border: 2px solid #E0E0E0">
  <!-- Brand -->
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(URL::asset('/images/logo/logo.png')); ?>" height="90" width="100"></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
    <a class="nav-link" href="<?php echo e(route('home')); ?>"><b></b><h5 style="color:#101010 !important">All Products</h5></b></a>
     <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('home.categoryProduct' , $category->id)); ?>"><b></b><h5 style="color:#101010 !important"><?php echo e($category->name); ?></h5></b></a>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </ul>
  
  


         <ul class="navbar-nav ml-auto">
             <?php if(auth()->guard()->guest()): ?>
             <li class="nav-item">
                 <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
             </li>
             <?php if(Route::has('register')): ?>
             <li class="nav-item">
                 <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
             </li>
             <?php endif; ?>
             <?php else: ?>
             <li class="nav-item dropdown">
                
                 <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                     <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                 </a>

                 <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    
                    <a class="dropdown-item" href="<?php echo e(route('home.userDashboard')); ?>" >
                         <?php echo e(__('My Dashboard')); ?>

                     </a>
                    
                    
                     <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                         <?php echo e(__('Logout')); ?>

                     </a>
                     

                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form>
                 </div>
             </li>
             <?php endif; ?>
         </ul>
     </div> 
</nav>
     <!-- End Navbar Part -->

 </div>

<?php /**PATH F:\laravel aiub\test\test\resources\views/home/partials/nav.blade.php ENDPATH**/ ?>