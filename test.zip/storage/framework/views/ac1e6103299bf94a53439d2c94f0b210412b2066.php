      <?php $__env->startSection('content'); ?>
      
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                  </div>
                  <div class="card-body">
                      <h3>Order Information</h3>
                <table border="0">
                    <tr>
                        <td>Product Name :</td>
                        <td><?php echo e($order->product->title); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Quantity :</td>
                        <td><?php echo e($order->quantity); ?></td>
                    </tr>
                    <tr>
                        <td>Price :</td>
                        <td><?php echo e($order->price); ?></td>
                    </tr>
                    <tr>
                        <td>Customer Name :</td>
                        <td><?php echo e($order->name); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Customer Number :</td>
                        <td><?php echo e($order->number); ?></td>
                    </tr>
                    <tr>
                        <td>Customer Address :</td>
                        <td>
                            <?php echo e($order->address); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <form action="<?php echo e(route('supplier.completeOrder' , $order->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php if($order->is_delivered): ?>
                                <input type="submit" class="btn btn-success" name="complete" value="Delivered">
                                <?php else: ?>
                                <input type="submit" class="btn btn-primary" name="complete" value="Pending Order">
                                <?php endif; ?>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('supplier.cancelOrder', $order->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <?php if($order->is_canceled): ?>
                                <input type="submit" class="btn btn-danger" name="complete" value="Cancelled">
                                <?php else: ?>
                                <input type="submit" class="btn btn-danger" name="complete" value="Cancel Order">
                                <?php endif; ?>
                            </form>

                        </td>
                    </tr>
                </table>
                     
                     
                  </div>
              </div>


          </div>
      </div>
      <!-- main-panel ends -->


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/supplier/pages/orderShow.blade.php ENDPATH**/ ?>