<?php $__env->startSection('content'); ?>

<div class="main-panel">
    <div class="content-wrapper">
        <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
                <h3>Admin Profile</h3>
                <table border="0">
                    <?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $std): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>category :</td>
                        <td><?php echo e($std['category']); ?></td>
                    </tr>
                    <tr>
                        <td>name :</td>
                        <td><?php echo e($std['name']); ?></td>
                    </tr>
                    <tr>
                        <td>email :</td>
                        <td><?php echo e($std['email']); ?></td>
                    </tr>
                    <tr>
                        <td>number :</td>
                        <td><?php echo e($std['number']); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Username :</td>
                        <td><?php echo e($std['username']); ?></td>
                    </tr>
                    <tr>
                        <td>Password :</td>
                        <td>
                            <?php echo e($std['password']); ?>

                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                     
                     
                  </div>
              </div>


          </div>
      </div>
      <!-- main-panel ends -->


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/profile.blade.php ENDPATH**/ ?>