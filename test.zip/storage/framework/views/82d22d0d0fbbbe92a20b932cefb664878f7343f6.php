      <?php $__env->startSection('content'); ?>
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                      Reseller Information
                  </div>
                  <div class="card-body">

                      <table class="table table-dark">
                          <thead>
                              <tr>
                                  <th scope="col">Name</th>
                                  <th scope="col">Category</th>
                                  <th scope="col">Email</th>
                                  <th scope="col">Number</th>
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <th scope="row"><?php echo e($value['name']); ?></th>
                                  <td><?php echo e($value['category']); ?></td>
                                  <td><?php echo e($value['email']); ?></td>
                                  <td><?php echo e($value['number']); ?></td>
                                  
                              </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
</table>

                  </div>
                  </div>


                  </div>
                  </div>
                  <!-- main-panel ends -->


                  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/adminShow.blade.php ENDPATH**/ ?>