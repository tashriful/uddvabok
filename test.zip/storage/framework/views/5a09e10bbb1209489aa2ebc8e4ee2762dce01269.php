<?php if(Session::has('success')): ?>
<div class="alert alert-success">
    
    <p><?php echo e(Session::get('success')); ?></p>
</div>
<?php endif; ?><?php /**PATH F:\laravel aiub\test\test\resources\views/home/layouts/success.blade.php ENDPATH**/ ?>