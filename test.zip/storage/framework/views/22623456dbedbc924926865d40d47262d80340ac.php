<div class="list-group">
          <a href="#" class="list-group-item list-group-item-action">First item</a>
          <a href="#" class="list-group-item list-group-item-action">Second item</a>
          <a href="#" class="list-group-item list-group-item-action">Third item</a>
        </div><?php /**PATH F:\laravel aiub\test\test\resources\views/home/partials/sidebar.blade.php ENDPATH**/ ?>