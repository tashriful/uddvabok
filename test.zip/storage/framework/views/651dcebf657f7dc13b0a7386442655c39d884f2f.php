<?php $__env->startSection('content'); ?>

  <!-- Start Sidebar + Content -->
  <div class='container margin-top-20'>
    <div class="row">
      <div class="col-md-4">
       <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'. $image->image)); ?>" alt="Card image" >
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div class="col-md-8">
       Name :<h2><?php echo e($product->title); ?></h2>
       Price :<h5><?php echo e($product->price); ?></h5>
        Quantity :<h5><?php echo e($product->quantity); ?></h5>

       
        
      </div>


    </div>
    
    <div class="row">
      <div class="col-md-12"  style="margin-top:50px;">
   
         <h4>Description :</h4>
         <h5><?php echo e($product->description); ?></h5>

      </div>


    </div>
  </div>

  <!-- End Sidebar + Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/home/pages/productShow.blade.php ENDPATH**/ ?>