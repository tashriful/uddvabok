<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
      
      body {
   background-color:#F5F5F5 !important;

}
    
  </style>
  <title>Home</title>

  <?php echo $__env->make('home.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('home.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

  <div class="wrapper">

    <?php echo $__env->make('home.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('home.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </div>


  </body>
</html><?php /**PATH F:\laravel aiub\test\test\resources\views/home/layouts/master.blade.php ENDPATH**/ ?>