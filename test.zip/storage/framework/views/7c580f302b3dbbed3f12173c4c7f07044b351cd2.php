      <?php $__env->startSection('content'); ?>
      
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                      Update Product
                  </div>
                  <div class="card-body">
                         

                     
                      <form action="<?php echo e(route('admin.productUpdate' , $product->id)); ?>" method="post" enctype="multipart/form-data" >
                        
                        <?php echo csrf_field(); ?>
                        
                         <?php echo $__env->make('admin.layouts.validationError', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                  
                         <div class="form-group">
                              <label for="exampleInputTitle">Product Title</label>
                              <input type="text" class="form-control" name="title" value="<?php echo e($product['title']); ?>">
                          </div>
                          
                       
                          <div class="form-group">
                            <label for="category">Product Category:</label>
                            <select class="form-control" name="category">
                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category['id']); ?>"><?php echo e($category['name']); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </select>
                        </div>
                         
                         <div class="form-group">
                            <label for="category">User Type:</label>
                            <select class="form-control" name="utype">
                               
                                <option value="Admin">Admin</option>
             
                            </select>
                        </div>
                         
                        <div class="form-group">
                            <label for="category">Status:</label>
                            <select class="form-control" name="status">
                     
                                <option value="1">Active</option>
                                <option value="0">Deactive</option>
                 
                               
                            </select>
                        </div>
                          
                          
                          <div class="form-group">
                              <label for="exampleInputDescription">Product Description</label>
                              <textarea class="form-control" name="description" rows="8" cols="70" ><?php echo e($product['description']); ?></textarea>
                              
                          </div>
                          
                          <div class="form-group">
                              <label for="quantity">Quantity</label>
                              <input type="number" class="form-control" name="quantity" value="<?php echo e($product['quantity']); ?>">
                              
                          </div>
                          
                          <div class="form-group">
                              <label for="price">Price</label>
                              <input type="number" class="form-control" name="price" value="<?php echo e($product['price']); ?>">
                              
                          </div>
                          
                          <div class="form-group">
                              <label for="price">My Price</label>
                              <input type="number" class="form-control" name="myprice" value="<?php echo e($product['My_Price']); ?>">
                              
                          </div>
                          
                          <div class="form-group">
                              <label for="product_image">Image</label>
                              <input type="file" class="form-control" name="image" placeholder="Enter Image">
                          </div>
                 
                          <button type="submit" name="submit" value="submit" class="btn btn-primary">Update</button>
                      </form>

                  </div>
              </div>


          </div>
      </div>
      <!-- main-panel ends -->


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/productEdit.blade.php ENDPATH**/ ?>