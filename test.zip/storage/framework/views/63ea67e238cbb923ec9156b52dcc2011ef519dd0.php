      <?php $__env->startSection('content'); ?>
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                      Account Information
                  </div>
                  <div class="card-body">

                      <table class="table table-dark">
                          <thead>
                              <tr>
                                  <th scope="col">Order No</th>
                                  <th scope="col">Price</th>
                                  <th scope="col">Reseller Name</th>
                                  <th scope="col">Reseller P'ammount</th>
                                  <th scope="col">Supplier Name</th>
                                  <th scope="col">Supplier P'ammount</th>
                                  <th scope="col">My Price</th>
                                  <th scope="col">Status</th>
                                  
                              </tr>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <th scope="row"><?php echo e($order['id']); ?></th>
                                  <th scope="row"><?php echo e($order['price']); ?></th>
                                  <td><?php echo e($order->user->name); ?></td>
                                  <td>

                                      <?php echo e($order['price']); ?>

                                      -
                                      <?php echo e(\App\product::where(['id' => $order->product_id])->pluck('My_Price')->first()); ?>

                                      =
                                      <?php echo e($order['price']- \App\product::where(['id' => $order->product_id])->pluck('My_Price')->first()); ?>

                                  </td>
                                  <td><?php echo e(\App\Supplier::where(['id' => $order->uploader_id])->pluck('name')->first()); ?>

                                  </td>
                                   <td>
                                  
                                  <?php echo e(\App\product::where(['id' => $order->product_id])->pluck('price')->first()); ?>

                                  </td>
                                  <td>
                                  <?php echo e(\App\product::where(['id' => $order->product_id])->pluck('My_Price')->first()); ?>

                                  </td>
                                  <td>
                                  <p>
                                      <?php if($order->is_paid): ?>
                                      <button type="button" class="btn btn-success btn-sm">Paid</button>
                                      <?php else: ?>
                                      <button type="button" class="btn btn-danger btn-sm">Unpaid</button>
                                      <?php endif; ?>
                                  </p>
                                  </td>
                              </tr>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
</table>
                  </div>
                  </div>


                  </div>
                  </div>
                  <!-- main-panel ends -->


                  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/admin/pages/account.blade.php ENDPATH**/ ?>