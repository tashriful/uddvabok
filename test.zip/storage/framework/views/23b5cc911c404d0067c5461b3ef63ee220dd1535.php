<?php $__env->startSection('content'); ?>

  <!-- Start Sidebar + Content -->
  <div class='container margin-top-20'>
    <div class="row">
      <div class="col-md-4">
      
      </div>

      <div class="col-md-8">
      <h1>Searched Products</h1>
       <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
       <?php echo e($search->title); ?>

        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>


    </div>
  </div>

  <!-- End Sidebar + Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/home/pages/search.blade.php ENDPATH**/ ?>