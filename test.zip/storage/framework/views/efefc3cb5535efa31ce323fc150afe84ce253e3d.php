<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Home</title>

  <?php echo $__env->make('home.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->make('home.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
  
  <div class="wrapper">

    <?php echo $__env->make('home.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
    

  </div>
   <div class='container-fluid margin-top-20'>
      

      <div style="background-color:" class="row">
          <div class="col-md-3">
              <div class="list-group"> 
                  <a href="<?php echo e(route('home.userDashboard')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('home.userDashboard') ? 'active' : ''); ?> "  >Dashboard</a>
                  <a href="<?php echo e(route('home.userProfile')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('home.userProfile') ? 'active' : ''); ?> ">Profile</a>
                  <a href="<?php echo e(route('home.userOrder')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('home.userOrder') ? 'active' : ''); ?> ">Ordered items</a>
                  <a href="<?php echo e(route('home.account')); ?>" class="list-group-item list-group-item-action <?php echo e(Route::is('home.account') ? 'active' : ''); ?> ">Accounts</a>
              </div>

          </div>

          <div style="" class="col-md-9">
             <div class="card card-body">

             <?php echo $__env->yieldContent('sub_content'); ?>;
             </div>
          
        </div>
    </div>
     <?php echo $__env->make('home.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
  
  

  


  </body>
</html><?php /**PATH F:\laravel aiub\test\test\resources\views/home/layouts/userMaster.blade.php ENDPATH**/ ?>