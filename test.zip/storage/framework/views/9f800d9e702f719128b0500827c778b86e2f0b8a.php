<?php $__env->startSection('sub_content'); ?>

   <div class='container-fluid margin-top-20'>

       <div class="card-body">
          <div class="card-header">
              
              <h3>Reseller Profile</h3>
          </div>
           <br>
           <table border="0">
              
               <tr>
                   <td>Category :</td>
                   <td><?php echo e($user['category']); ?></td>
               </tr>
               <tr>
                   <td>Name :</td>
                   <td><?php echo e($user['name']); ?></td>
               </tr>
               <tr>
                   <td>Email :</td>
                   <td><?php echo e($user['email']); ?></td>
               </tr>
               <tr>
                   <td>Number :</td>
                   <td><?php echo e($user['number']); ?></td>
               </tr>

               <tr>
                   <td>Username :</td>
                   <td><?php echo e($user['username']); ?></td>
               </tr>
               <tr>
                   <td>Password :</td>
                   <td>
                       <?php echo e($user['password']); ?>

                   </td>
               </tr>
            
           </table>


       </div>

   </div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layouts.userMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laravel aiub\test\test\resources\views/home/pages/userProfile.blade.php ENDPATH**/ ?>